// ===== Site config =====
const TOKEN = "dc-2025-physio"; // Zugangscode (QR-Token)
// ===== Gate logic (works across all pages) =====
const gate = document.getElementById('gate');
const content = document.getElementById('content');
function showContent(){ if(gate) gate.style.display='none'; if(content) content.style.display='block'; }
function showGate(){ if(gate) gate.style.display='flex'; if(content) content.style.display='none'; }
function saveOpen(){ try{ localStorage.setItem('gate_ok', TOKEN); }catch(e){} }
function isOpen(){ try{ return localStorage.getItem('gate_ok') === TOKEN; }catch(e){ return false; } }
function tryOpenFromURL(){ const p=new URLSearchParams(location.search).get('k'); if(p && p===TOKEN){ saveOpen(); return true; } return false; }
function initGate(){
  if(!gate || !content) return;
  if(isOpen()||tryOpenFromURL()) showContent(); else showGate();
  const form=document.getElementById('gateForm'); 
  if(form) form.addEventListener('submit', (e)=>{ e.preventDefault(); const v=document.getElementById('pin').value.trim(); if(v===TOKEN){ saveOpen(); showContent(); const url=new URL(location.href); url.searchParams.delete('k'); history.replaceState(null,'',url.toString()); } });
}
// ===== Theme toggle =====
function initTheme(){
  const saved = localStorage.getItem('theme');
  if(saved==='dark' || (!saved && window.matchMedia('(prefers-color-scheme: dark)').matches)) document.documentElement.classList.add('dark');
  const t = document.getElementById('themeToggle');
  if(t) t.addEventListener('click', ()=>{
    document.documentElement.classList.toggle('dark');
    localStorage.setItem('theme', document.documentElement.classList.contains('dark')?'dark':'light');
  });
}
// ===== Nav active marker =====
function setActiveNav(){
  const here = location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('nav .navlinks a').forEach(a=>{ if(a.getAttribute('href')===here) a.classList.add('active'); });
}
// ===== Logout =====
function initLogout(){
  const out = document.getElementById('logout');
  if(out) out.addEventListener('click', (e)=>{ e.preventDefault(); localStorage.removeItem('gate_ok'); location.href = 'index.html'; });
}
// ===== Footer year =====
function setYear(){
  const y = document.getElementById('year'); if(y) y.textContent = new Date().getFullYear();
}
// ===== Init =====
window.addEventListener('DOMContentLoaded', ()=>{ initGate(); initTheme(); setActiveNav(); initLogout(); setYear(); });