# Dan Christoff – Bewerbungsseite (Multi-Page)

## Dateien hochladen
- Alle Dateien/Ordner in dieses Repo laden (Root).
- GitHub Pages: Settings → Pages → Deploy from a branch → Branch `main` + Folder `(root)`.

## Token (Zugangscode) ändern
- In `assets/script.js` die Zeile: `const TOKEN = "dc-2025-physio";` ersetzen.
- QR-Link immer mit `?k=DEIN_TOKEN` aufrufen.

## Farben/Bild/Text ändern
- Farbe: `assets/style.css` → `--accent:` anpassen.
- Foto: lade `foto.jpg` hoch und ersetze in `index.html` den Avatar-Block durch ein `<img>`.
- Texte: direkt in den jeweiligen HTML-Dateien bearbeiten.